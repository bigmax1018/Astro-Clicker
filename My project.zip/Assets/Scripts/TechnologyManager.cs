using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TechnologyManager : MonoBehaviour
{
    [SerializeField] private GameObject[] TechnologyList;
    private int NbLine;
    private string[][] Tab = new string[10][];

    private int price;

    // Start is called before the first frame update
    void Start()
    {
        UpgradeScrollBarToggle WindowManager = GameObject.Find("LeftMenu").GetComponent<UpgradeScrollBarToggle>();
        WindowManager.firstOpening += InitializeButtons;

        Tab[3] = new string[3]{"Terraforming Device","5000","For restoring scorching planets"};
        Tab[1] = new string[3]{"Research Lab","5000","For unlocking new technology"};
        Tab[0] = new string[3]{"Space Station","3000","For unlocking new troops and intergalactic travel"}; // new troops?
        Tab[2] = new string[3]{"Black Hole","3000","For destroying alien UFO's stealing crystals"};
        Tab[4] = new string[3]{"AIM Weapon","1000","Sniper rifle fo shooting UFO's"};
        Tab[5] = new string[3]{"Quantum Spacetime Resilience Field Generator","5000","Unlocks the ability to travel inside black holes"};
        Tab[7] = new string[3]{"Celestial Hazard Mastery","500000","Unlocks the ability to access the Blue Dwarfs and get bonuses for the game"};
        Tab[6] = new string[3]{"Stellar Temporal Time Accelerator","1000000","Unlocks the ability to change the time-phase for the Blue Dwarf to Black Dwarf"};
        Tab[8] = new string[3]{"Mini Black Hole Generator","10000","Unlocks the ability to generate up to 3 mini Black Holes at once"};
        Tab[9] = new string[3]{"Astro Field","500000","Unlock the ability to double the amount of crystals per second"};

        InitializeButtons();
    }

    public void InitializeButtons(){
         if(TechnologyList.Length <= 10){
            for(int i = 0; i<TechnologyList.Length; i++){
                GameObject Tech =  TechnologyList[i];
                Technology technology = Tech.GetComponent<Technology>();
                technology.Name = Tab[i][0];
                if(int.TryParse(Tab[i][1], out price)){
                    technology.Price = price;
                    technology.displayPrice();}
                technology.Detail = Tab[i][0] + " : " + Tab[i][2];
            }
        }
        else{
            Debug.Log("Not enough information in the list");
        }
    }
}

