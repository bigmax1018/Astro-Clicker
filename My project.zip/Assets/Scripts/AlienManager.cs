using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlienManager : MonoBehaviour
{
    //public GameObject AlienPrefab;
    [SerializeField] private GameObject[] Alien;
    private float AlienNb = 3;
    AddCristal CrystalManager;
    Planet PlanetManager;

    private bool IsFiring = false;
    // Start is called before the first frame update
    void Start()
    {
        CrystalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
        PlanetManager = GameObject.Find("Planet").GetComponent<Planet>();

        foreach (GameObject alien in Alien){
                alien.SetActive(false);
            }
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.A) && !IsFiring){
            //Debug.Log("Fired!");
            StartCoroutine(FireAliens());
        }
        
    }

    IEnumerator FireAliens(){
        IsFiring = true;
        //int i = 0;
        AlienNb = 3 * PlanetManager.PlanetCount;
        /*while(i<AlienNb){
            i ++;
            Instantiate(AlienPrefab,GameObject.Find("Canvas").transform);

            yield return new WaitForSeconds(.5f);
            }*/
        for(int n = 0; n<=AlienNb-1; n++ ){
            Alien[n].SetActive(true);
            //yield return new WaitForSeconds(.5f);
        }
        yield return new WaitForSeconds(5f);
        IsFiring = false;
    }
}
