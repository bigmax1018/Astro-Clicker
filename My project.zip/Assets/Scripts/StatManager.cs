using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StatManager : MonoBehaviour
{
    public TMP_Text[] Stats;
    public int[] StatValue;

    public GameObject CrystalM;
    AddCristal addCrystal;
 

    void Awake(){
        addCrystal = CrystalM.GetComponent<AddCristal>();
        StatValue = new int[Stats.Length];
    }

    void OnEnable(){
        if(addCrystal != null){
        AddCrystal(addCrystal.CurrentType);
        DisplayValues();}
        else
        Debug.Log("CrystlaManager not found!");
    }

    void Update(){
        AddCrystal(addCrystal.CurrentType);
        DisplayValues();}
    

    public void AddCrystal(Crystals Type){
        switch(Type){
            case Crystals.Green:
                StatValue[0] = addCrystal.Count;
                break;
            case Crystals.Mars:
                StatValue[0] = addCrystal.Count;
                break;
            case Crystals.Venus:
                StatValue[0] = addCrystal.Count;
                break;
            case Crystals.Blue:
                StatValue[1] = addCrystal.Count;
                break;
            case Crystals.Jupiter:
                StatValue[1] = addCrystal.Count;
                break;
            case Crystals.Orange:
                StatValue[2] = addCrystal.Count;
                break;
            case Crystals.Uranus:
                StatValue[2] = addCrystal.Count;
                break;
            case Crystals.Purple:
                StatValue[3] = addCrystal.Count;
                break;
            case Crystals.Pluto:
                StatValue[3] = addCrystal.Count;
                break;
            case Crystals.White:
                StatValue[4] = addCrystal.Count;
                break;
            case Crystals.Sun1:
                StatValue[4] = addCrystal.Count;
                break;
            case Crystals.Sun2:
                StatValue[4] = addCrystal.Count;
                break;
            case Crystals.Sun3:
                StatValue[4] = addCrystal.Count;
                break;
            default:
                break;
        }
        
    }

    public void DisplayValues(){
        AddCrystal(addCrystal.CurrentType);
        for(int i = 0; i<Stats.Length; i++){
            if(i == 5){
                StatValue[i] =0;
                for(int j =0; j<i; j++){
                    StatValue[i] += StatValue[j];
                }
                Stats[i].text = StatValue[i].ToString();
            }
            else if (i == 7){
                Stats[i].text = StatValue[i].ToString() + "/15";
            }
            else if (i == 8){
                Stats[i].text = StatValue[i].ToString() + "/5";
            }
            else{
                Stats[i].text = StatValue[i].ToString();

            }
        }
        Stats[Stats.Length -1].text = "?????";
    }

    public void TerraformedPlanet(){

    }

    public void AchievementCount(){

    }

    public void MarvelCount(){

    }

    public void PlanetCount(){

    }

    public int GetValue(int n){
        Debug.Log(n);
        if(n<3){
            return  StatValue[0];
        }
        else if ((n>=3)&&(n<5)){
            return  StatValue[1];
        }
        else if ((n>=5)&&(n<7)){
            return  StatValue[2];
        }
        else if ((n>=7)&&(n<9)){
            return  StatValue[3];
        }
        else{
            return  StatValue[4];
        }
    }

}
