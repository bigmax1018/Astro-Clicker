using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    [SerializeField] private GameObject[] UpgradeList;
    private int NbLine;
    private string[][] Tab = new string[12][];

    private int price, earning;
    //private int[][] UpgradesHistory = new int[10][12];
    // Start is called before the first frame update
    void Start()
    {
        UpgradeScrollBarToggle WindowManager = GameObject.Find("LeftMenu").GetComponent<UpgradeScrollBarToggle>();
        WindowManager.firstOpening += InitializeButtons;
        
        //initialize buttons display//
        Tab[0] = new string[3]{"Enhanced click","10","-5"};
        Tab[1] = new string[3]{"Auto click","30","5"};
        Tab[2] = new string[3]{"Rover","100","7"};
        Tab[3] = new string[3]{"Mining Team","300","15"};
        Tab[4] = new string[3]{"UFO Miner","900","18"};
        Tab[5] = new string[3]{"C Satellite","1000","20"};
        Tab[6] = new string[3]{"I.R. Mecha","1500","23"};
        Tab[7] = new string[3]{"Robot1","1800","25"};
        Tab[8] = new string[3]{"Robot2","2100","30"};
        Tab[9] = new string[3]{"Robot3","2400","35"};
        Tab[10] = new string[3]{"Robot4","2700","38"};
        Tab[11] = new string[3]{"Robot5","3000","40"};

       /* //initialize buttons history per planet//
        for(int i = 0; i<10;i++ ){
            for(int j = 0; j<12;j++){
                UpgradesHistory[i][j] = 0;
            }
        }*/
        
    }

    public void InitializeButtons(){
         if(UpgradeList.Length <= 12){
            for(int i = 0; i<UpgradeList.Length; i++){
                GameObject upgrade =  UpgradeList[i];
                Upgrade upgradeScript = upgrade.GetComponent<Upgrade>();
                upgradeScript.Name = Tab[i][0];
                if(int.TryParse(Tab[i][1], out price)){
                    upgradeScript.Price = price;
                    upgradeScript.initialPrice = price;
                    upgradeScript.displayPrice();}
                
                if(int.TryParse(Tab[i][2], out earning)){
                    upgradeScript.Earning = earning;
                    upgradeScript.initialEarning = earning;}
                upgradeScript.displayEarning();
            }
        }
        else{
            Debug.Log("Not enough informetion in the list");
        }
    }

}
