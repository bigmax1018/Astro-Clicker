using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Technology : MonoBehaviour
{
    public string Name;
    public int Price;
    public string Detail;

    AddCristal CristalManager;
    Planet planet;

    public Image Cristal, ButtonIcon;
    //private TMP_Text NameText;
    public TMP_Text PriceText,LockText;

    public Button Button;
    private int UsesTrack = 0, CurrentPos=0;
    private bool IsUsed = false;
    private bool[] UsesHistory = new bool[13];
    
    // Start is called before the first frame update
    void Awake()
    {

        CristalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
        CristalManager.NewPlanet += Reset;
        CristalManager.OldPlanet += Load;
        planet = GameObject.Find("Planet").GetComponent<Planet>();

        PriceText.text = Price.ToString();

        Button.onClick.AddListener(TaskOnClick);

        Cristal.sprite = CristalManager.CristalInUse;
    }

    public void ShowDetail(){
        planet.DisplayDetail(Detail);
    }
    public void HideDetail(){
        planet.DisplayDetail("");
    }


    public void Use(){ //make a particular function for the terraforming device
        IsUsed = true;
        Cristal.enabled = false;
        PriceText.text = "";
        LockText.text = "Activate";
    }

    public void Reset(){
        UsesHistory[UsesTrack] = IsUsed;
        UsesTrack ++;
        CurrentPos ++;
        IsUsed = false;
        PriceText.text = Price.ToString();
        Cristal.enabled = true;
        Cristal.sprite = CristalManager.CristalInUse;
        LockText.text = "Locked";
    }

    
    public void Load(int n){
        UsesHistory[CurrentPos] = IsUsed;
        CurrentPos = n;
        IsUsed = UsesHistory[n];
        if(!IsUsed){
            Reset();
        }
        else{
                bool use = CristalManager.UnlockTech(0, Name);
                Use();
        }
    }
    
    public void displayPrice(){
        PriceText.text = Price.ToString();
    }

    public void TaskOnClick(){
        bool TryUse = CristalManager.UnlockTech(Price, Name);

        if (TryUse){
            Use();
        }
    }
}
