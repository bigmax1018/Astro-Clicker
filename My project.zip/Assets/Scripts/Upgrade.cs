using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Upgrade : MonoBehaviour
{

    [HideInInspector] public string Name;
    [HideInInspector] public int Price, initialPrice, initialEarning;
    [HideInInspector] public int Earning = 0;
    [HideInInspector] public string Detail;

    AddCristal CristalManager;
    Planet planet;

    public Image Cristal, ButtonIcon;
    //private TMP_Text NameText;
    public TMP_Text PriceText,LevelText;

    public Button Button;
    private int Level = 0, TrackPos = 0, CurrentPos=0;
    private int[] TrackLevel = new int[13];
    // Start is called before the first frame update
    void Awake()
    {

        CristalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
        CristalManager.NewPlanet += Reset;
        CristalManager.OldPlanet += Load;
        planet = GameObject.Find("Planet").GetComponent<Planet>();

        //NameText.text = Name;
        initialPrice = Price;
        PriceText.text = Price.ToString();
        initialEarning = Earning;

        //Button = this.gameObject.GetComponent<Button>();
        Button.onClick.AddListener(TaskOnClick);

       


    }
    
    void Start(){
         Cristal.sprite = CristalManager.CristalInUse;
    }

    public void ShowDetail(){
        planet.DisplayDetail(Detail);
    }
    public void HideDetail(){
        planet.DisplayDetail("");
    }


    public void Use(){//fonction de level up a la place
        Level += 1;
        LevelText.text = "Level " + Level;
        
        Price += initialPrice;
        PriceText.text = Price.ToString();

        /*if(Earning > 0){
            Earning += initialEarning;
                }
        else{
            Earning += initialEarning;
        }*/
        Earning = initialEarning*(Level+1);
        displayEarning();
        
        //Cristal.enabled = false;*/
    }

    public void Reset(){
        TrackLevel[TrackPos] = Level;
        TrackPos ++;
        CurrentPos ++;

        Price = initialPrice;
        PriceText.text = Price.ToString();

        Level = 0;
        LevelText.text = "Locked";

        Cristal.enabled = true;
        Cristal.sprite = CristalManager.CristalInUse;

        Earning = initialEarning;
        displayEarning();
    }

    public void Load(int n){
        TrackLevel[CurrentPos] = Level;
        CurrentPos = n;
        Level = TrackLevel[n];
        if(Level ==0 ){
            Reset();
        }
        else{
            for(int i=0; i <= Level; i++){
                bool raise = CristalManager.RaiseEarnings(Earning, 0, Name);
                Use();
            }
        }
    }

    public void displayEarning(){
        if(Earning > 0){
            Detail = Name + " : Get " + Earning + " crystals per second";
                }
        else{
            Detail = Name + " : Get "+ -1*Earning + " crystals per click";
        }
    }
    
    public void displayPrice(){
        PriceText.text = Price.ToString();
    }

    public void TaskOnClick(){
        bool TryUse = CristalManager.RaiseEarnings(Earning, Price, Name);

        if (TryUse){
            Use();
        }
    }
}
