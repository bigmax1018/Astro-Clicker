using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeScrollBarToggle : MonoBehaviour
{
    [SerializeField] private GameObject UpgradeWindow,TechnologyWindow,StatWindow;
    [SerializeField] private Color OpenColor, CloseColor;
    [SerializeField] private Image UpgradeTab,TechnologyTab,StatTab;
    [SerializeField] private Scrollbar UpgradeScrollBar;
    public Animator ScrollBarAnim;
    private bool IsActive = false, FirstOpening = true;
    public Sprite OpenButton, CloseButton; 
    public Image Icon;
    public GameObject ContentManager;
    UpgradeManager upgradeManager;

    public event Notify firstOpening;

    public void Toggle(){
        if(IsActive){
            ScrollBarAnim.SetTrigger("Close");
            IsActive = false;
            Icon.sprite = CloseButton;

        }
        else{
            ScrollBarAnim.SetTrigger("Open");
            IsActive = true;
            Icon.sprite = OpenButton;  

            
            ChangePanel(UpgradeWindow);
        }
    }
    public void EndAnim(){
        UpgradeScrollBar.value = 1;
        if(FirstOpening){
                FirstOpening = false;
                firstOpening?.Invoke();
                /*upgradeManager = ContentManager.GetComponent<UpgradeManager>();
                upgradeManager.InitializeButtons();*/
        }
    }

    public void Close(){
        if(IsActive){
            ScrollBarAnim.SetTrigger("Close");
            IsActive = false;
            Icon.sprite = CloseButton;
        }
    }
    public void ChangePanel(GameObject ActivePanel){
        if(ActivePanel == UpgradeWindow){
            UpgradeWindow.SetActive(true);
            TechnologyWindow.SetActive(false);
            StatWindow.SetActive(false);

            UpgradeTab.color = OpenColor;
            TechnologyTab.color = CloseColor;
            StatTab.color = CloseColor;
        }
        else if(ActivePanel == TechnologyWindow){
            UpgradeWindow.SetActive(false);
            TechnologyWindow.SetActive(true);
            StatWindow.SetActive(false);

            UpgradeTab.color = CloseColor;
            TechnologyTab.color = OpenColor;
            StatTab.color = CloseColor;
        }
        else{
            UpgradeWindow.SetActive(false);
            TechnologyWindow.SetActive(false);
            StatWindow.SetActive(true);

            UpgradeTab.color = CloseColor;
            TechnologyTab.color = CloseColor;
            StatTab.color = OpenColor;
        }
        /*if(ActivePanel == MarvelPanel){
                MarvelPanel.SetActive(true);
                AchievementPanel.SetActive(false);

                MarvelTab.color = OpenColor;
                AchievementTab.color = CloseColor;

                MarvelText.color = Color.black;
                AchievementText.color = Color.white;

                GetComponent<RectTransform>().sizeDelta = MarvelSize;*/
    }

    public void OpenUpgrades(){
        ChangePanel(UpgradeWindow);
    }
    public void OpenTechnology(){
        ChangePanel(TechnologyWindow);
    }
    public void Openstat(){
        ChangePanel(StatWindow);
    }
}
