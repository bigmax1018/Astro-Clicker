using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LittlePlanetManager : MonoBehaviour
{
    [SerializeField] private GameObject[] Buttons;
    private int Rank = 0;

    AddCristal CrystalManager;

    void Start(){
        Activate();
        CrystalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
        CrystalManager.NewPlanet += Activate;
    }

    private void Activate(){
        Buttons[Rank].SetActive(true);
        Rank ++;
    }
}
