using UnityEngine;
using System.Collections;
using TMPro;

public class DisplayFPS : MonoBehaviour
{
    public TMP_Text fpsText;
    public TMP_Text TimeScaleText;
	public float deltaTime;

	void Update () {
		deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
		float fps = 1.0f / deltaTime;
		fpsText.text = Mathf.Ceil (fps).ToString ();
        TimeScaleText.text = Time.timeScale.ToString();
	}
}
