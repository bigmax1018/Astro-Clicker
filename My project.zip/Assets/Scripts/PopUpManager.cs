using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PopUpManager : MonoBehaviour
{
    public GameObject AchievementAnim;
    private Image IconAnim;
    private Queue<Sprite> PopUpQueue = new Queue<Sprite>();
    private float t =0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if((PopUpQueue.Count != 0) && t>=0.5f){
            GameObject AnimClone = Instantiate(AchievementAnim,GameObject.Find("Canvas").transform);
            IconAnim = AnimClone.GetComponent<Image>();
            Sprite Icon = PopUpQueue.Dequeue();
            IconAnim.sprite = Icon;

            t = 0f;
        }
        else if ((PopUpQueue.Count != 0) && t<0.5f){
            t += Time.deltaTime;
        }
        
    }

    public void AddToPopUpQueue(Sprite Icon){
        PopUpQueue.Enqueue(Icon);
    }
}
