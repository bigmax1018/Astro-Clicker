using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class Planet : MonoBehaviour
{
    private Vector3 Pos;
    public TMP_Text DetailText, NovaDetailText;
    public Sprite[] PlanetArray;
    public int TravelCost = 1000;

    private Queue<Sprite> PlanetSprite = new Queue<Sprite>();
    private SpriteRenderer PlanetImage;
    [HideInInspector] public int PlanetCount = 1;
    private Vector3 DefaultSize, SpecialSize;
    private RectTransform PlanetTransform;
    [HideInInspector] public int ArrayPos=0, PlanetInUse =0;

    AddCristal CrystalManager;

    void Start(){
        

        /*foreach(Sprite Planet in PlanetArray){
            PlanetSprite.Enqueue(Planet);
        }*/

        PlanetImage = GetComponent<SpriteRenderer>();
        //PlanetImage.sprite = PlanetSprite.Dequeue();
        PlanetImage.sprite = PlanetArray[ArrayPos];
        DefaultSize = new Vector3(0.93f,0.93f,0f);
        //SpecialSize = new Vector3(1.5f,1.5f,0f);
        //PlanetTransform = GetComponent<RectTransform>();
        transform.localScale = DefaultSize;

        CrystalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
    }

    public void EndAnim()
    {
        ChangePlanet(CrystalManager.ArrayPos);
        
    }

    public void ChangePlanet(int NewPlanet){
        if(NewPlanet<PlanetArray.Length){
            PlanetImage.sprite = PlanetArray[NewPlanet];
            if(NewPlanet == 6){
                    transform.localScale =new Vector3(1.5f,1.5f,0f);
                }
            else if (NewPlanet == 5 ){
                transform.localScale =new Vector3(1.7f,1.7f,0f);
            }
            else{
                transform.localScale = DefaultSize;
            }
        }
        PlanetInUse = NewPlanet;
        if(PlanetInUse>ArrayPos){
            ArrayPos =PlanetInUse;
        }
        Pos = transform.position;
        transform.position = new Vector3(Pos.x,8.69f,0f);
        gameObject.GetComponent<Animator>().SetTrigger("Enter");

    }

    public void DisplayDetail(string detail){
        DetailText.text = detail;
    }
    public void NovaDisplayDetail(string detail){
        NovaDetailText.text = detail;
    }

    public void ShutDetail(){
        DetailText.text = "";
        NovaDetailText.text = "";
    }

    public bool CanTravelToNewPlanet(int n){
        if((PlanetInUse == ArrayPos) && (ArrayPos < 12) && (n>=TravelCost)){
            return true;
        }
        else{
            return false;
        }
    }
}
