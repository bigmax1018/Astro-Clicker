using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Alien : MonoBehaviour
{
    public Sprite ActionIcon, MovingIcon;
    public float DistSpeed = 10, SizeSpeed = 1, Side;
    public int StealTime = 30;
    private RectTransform AlienRect;
    private SpriteRenderer Icon;
    private bool IsMoving = true, CanLeave = false;
    public GameObject CrystalPrefab;

    private float Height, Width, StartHeight = 1f, StartWidth = 1f, FHeight = .5f, FWidth = .5f, DistStep, SizeStep;
    private Vector2 StartPos;

    AddCristal CrystalManager;
    // Start is called before the first frame update
    void Start()
    {
        Icon = GetComponent<SpriteRenderer>();
        CrystalManager = GameObject.Find("CrystalManager").GetComponent<AddCristal>();
        //Icon.sprite = MovingIcon;

       
        Height = StartHeight;
        Width = StartWidth;

        DistStep = Time.deltaTime * DistSpeed;
        SizeStep = Time.deltaTime * SizeSpeed;
        
        //AlienRect = GetComponent<RectTransform>();
        StartPos = transform.position; //AlienRect.anchoredPosition;

        //AlienRect.sizeDelta = new Vector2(StartWidth, StartHeight);
        transform.localScale = new Vector3(StartWidth, StartHeight,0f);

        //Debug.Log("Start Done");
    }

    void OnEnable(){
        //chose a random postion for the alien
        Side = Random.Range(-1f,1f);
        if(Side >0){
            Side = 1f;
            transform.rotation = Quaternion.Euler(0f, 0f, 0f);//flip the image if on left side
        }
        else{
            Side = -1f;
            transform.rotation = Quaternion.Euler(0f, 179f, 0f);//flip the image if on left side
        }

        //AlienRect = GetComponent<RectTransform>();
        /*AlienRect.anchoredPosition= new Vector2(682f*Side, Random.Range(-255f,255f));
        StartPos = AlienRect.anchoredPosition;*/
        transform.position = new Vector3(10f*Side, Random.Range(-4.6f,4.6f), 0f);
        StartPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if(SqrMgnt(transform.position) >= 3f && IsMoving){ //moving the alien to the planet while schrinking it
            transform.position = Vector3.MoveTowards(transform.position, Vector3.zero, DistStep);
            //AlienRect.anchoredPosition = LerpV(AlienRect.anchoredPosition, Vector2.zero, DistStep); //sameProb
            if (Height > FHeight){
            Height = Mathf.Lerp(Height, FHeight, SizeStep);
            Width = Mathf.Lerp(Width, FWidth, SizeStep);
            transform.localScale = new Vector3(Width, Height, 0f);}
            //Debug.Log("First Check ok");
        }
        else if (SqrMgnt(transform.position) < 3f && IsMoving) {// when finish moving, start taking cristals
                IsMoving = false;
                StartCoroutine(TakeCrystals());
        }

        /*if(IsMoving && !CanLeave){
            Icon.sprite = ActionIcon;
            IsMoving = false;
            StartCoroutine(TakeCrystals());
        }*/

        if(CanLeave){// when finish taking cristals, strat going back
             if(Vector2.Distance(transform.position,StartPos)>0.1f){
                
                transform.position = Vector3.MoveTowards(transform.position, StartPos, DistStep);
                if (Height < StartHeight){
                    Height = Mathf.Lerp(Height, StartHeight, SizeStep);
                    Width = Mathf.Lerp(Width, StartWidth, SizeStep);
                    transform.localScale = new Vector3(Width, Height, 0f);}
            }
            else{
                //Destroy(gameObject);
                CanLeave = false;
                IsMoving = true;
                gameObject.SetActive(false);
            }}
        
    }

    IEnumerator TakeCrystals(){
        Icon.sprite = ActionIcon;
        int i = 0;
        while(i<StealTime){ //take a cristal every second for 30 seconds
            i+= 1;
            GameObject crystal = Instantiate(CrystalPrefab,this.gameObject.transform);
            SpriteRenderer crystalImage = crystal.GetComponent<SpriteRenderer>();
            crystalImage.sprite = CrystalManager.CristalInUse;
            CrystalManager.AlienAttack();
            yield return new WaitForSeconds(1);
        }
        CanLeave = true;
        Icon.sprite = MovingIcon;
        
    }

    private float SqrMgnt(Vector2 v){ //custom square magnitude, the unity one don't work for vector2
        return Mathf.Sqrt(Mathf.Pow(v.x,2) + Mathf.Pow(v.y,2) );
    }

    private Vector2 LerpV(Vector2 Pos, Vector2 Dest, float Speed){
        return new Vector2(Mathf.Lerp(Pos.x, Dest.x, Speed),Mathf.Lerp(Pos.y, Dest.y, Speed));
    }

}
