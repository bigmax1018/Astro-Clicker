using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class NovaWindow : MonoBehaviour
{
    public GameObject Window, MarvelPanel, AchievementPanel, PlanetButton;
    private bool Open = false;
    public Image MarvelTab, AchievementTab;
    public Animator NovaAnim;
    public Image IconImage;
    
    public Color OpenColor, CloseColor, OpenIcon, CloseIcon;
    private TMP_Text MarvelText, AchievementText;
    
    private Vector2 MarvelSize = new Vector2(288f,222f), AchievementSize= new Vector2(212f,158f);

    Planet planet;
    // Start is called before the first frame update
    void Start()
    {

        MarvelText = MarvelTab.GetComponentInChildren<TMP_Text>();
        AchievementText = AchievementTab.GetComponentInChildren<TMP_Text>();
        planet = PlanetButton.GetComponent<Planet>();

        //IconImage = GetComponent<Image>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ToggleWindow(){
        if(Open){
            //Window.SetActive(false);
            Open= false;
            planet.NovaDisplayDetail("");
            NovaAnim.SetTrigger("Close");
            IconImage.color = CloseIcon;
        }
        else{
            //Window.SetActive(true);
            Open= true;
            OpenAchievements();
            NovaAnim.SetTrigger("Open");
            IconImage.color = OpenIcon;
        }
    }

    public void Close(){
        if(Open){
            //Window.SetActive(false);
            Open= false;
            planet.NovaDisplayDetail("");
            NovaAnim.SetTrigger("Close");
            IconImage.color = CloseIcon;
        }
    }

    public void ChangePanel(GameObject ActivePanel){
        if(ActivePanel == MarvelPanel){
                MarvelPanel.SetActive(true);
                AchievementPanel.SetActive(false);

                MarvelTab.color = OpenColor;
                AchievementTab.color = CloseColor;

                MarvelText.color = Color.black;
                AchievementText.color = Color.white;

                GetComponent<RectTransform>().sizeDelta = MarvelSize;
        }
        else if (ActivePanel == AchievementPanel){
                MarvelPanel.SetActive(false);
                AchievementPanel.SetActive(true);

                MarvelTab.color = CloseColor;
                AchievementTab.color = OpenColor ;

                MarvelText.color = Color.white;
                AchievementText.color = Color.black;
                GetComponent<RectTransform>().sizeDelta = AchievementSize;
                }

    }

    public void OpenAchievements(){
        ChangePanel(AchievementPanel);
    }

    public void OpenMarvel(){
        ChangePanel(MarvelPanel);
    }
}
