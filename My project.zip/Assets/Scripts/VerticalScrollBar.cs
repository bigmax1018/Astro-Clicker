using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VerticalScrollBar : MonoBehaviour
{
    public Scrollbar ScrollBar;

    void InitValue(){
        ScrollBar.value = 1;
    }
}
