using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using UnityEngine.UI;

public delegate void Notify();
public delegate void Notify2(int nb);

public enum Crystals{
    Green,
    Mars,
    Venus,
    Blue,
    Jupiter,
    Orange,
    Uranus,
    Purple,
    Pluto,
    White,
    Sun1,
    Sun2,
    Sun3,
    
}

public class AddCristal : MonoBehaviour
{
    //Display crystal count//
    public TMP_Text CountText;
    public int Count;
    public Image CristalImage;

    //Accessing to planet script//
    public Animator PlanetMovement;
    public GameObject PlanetButton;
    Planet PlanetScript;

    // Appearing GameObjects//
    public GameObject NewPlanetButton;
    public GameObject VisualGainTextPrefab;

    //Calculate cristals//
    private float time;
    private int ClickValue = 1, Earning = 0;
    //private bool ClickEnhance = false;
    private List<string> ButtonInUse;
    private List<string> TechInUse;

    //Changing crystal type//
    public Sprite[] CristalArray;
    private Queue<Sprite> CristalSprite = new Queue<Sprite>();
    [HideInInspector] public Sprite CristalInUse;
    //private int[] LoopBeforeCrystalChange ={3,2,2,2,0};
    [HideInInspector] public int LoopCount = 1, ArrayPos = 0;
    
    //Changing planet event//
    public event Notify NewPlanet;
    public event Notify2 OldPlanet;
    public GameObject StatObject;
    StatManager statManager;

    //Achievement unlocking//
    private Queue<Crystals> CrystalTypes = new Queue<Crystals>();
    [HideInInspector] public Crystals TypeInUse, CurrentType;

    //Indicates impossible actions//
    [SerializeField] private GameObject Info;
    Vector3 InfoPos ;
    TMP_Text InfoText;

    void Awake(){//initializing the frist type and first crystal

        /*foreach(Sprite Crystal in CristalArray){
            CristalSprite.Enqueue(Crystal);
        }
        CristalInUse = CristalSprite.Dequeue();*/
        CristalInUse = CristalArray[0];
        CristalImage.sprite = CristalInUse;

        foreach(Crystals crystal in Enum.GetValues(typeof(Crystals))){
            CrystalTypes.Enqueue(crystal);
        }
        TypeInUse = CrystalTypes.Dequeue();
        CurrentType = TypeInUse;

    }
    // Start is called before the first frame update
    void Start()
    {
        Count = 0;
        CountText.text = Count.ToString();
        time = 0f;
        NewPlanetButton.SetActive(false);
        ButtonInUse = new List<string> {};
        TechInUse = new List<string> {};
        PlanetScript = PlanetButton.GetComponent<Planet>();

        InfoText = Info.GetComponent<TMP_Text>();
        InfoPos = Info.transform.localPosition;

        statManager = StatObject.GetComponent<StatManager>();
        
    }

    void Update(){
        // Refreshing the cristals every seconds
            if(time<1){
                time += Time.deltaTime;
            }
            else{
                time =0;
                Count += Earning;
                CountText.text = Count.ToString();
                if(Earning > 0){
                VisualGain(Earning);}
            }
        
        if(PlanetScript.CanTravelToNewPlanet(Count)){ 
            NewPlanetButton.SetActive(true);
        }
        else{
            NewPlanetButton.SetActive(false);
        }

        if(Input.GetKeyDown("space")){ //temporary
            Count += 10000;
        }
    }

    public void Click(){
        Count += ClickValue;
        CountText.text = Count.ToString();
        VisualGain(ClickValue);
    }


    public bool RaiseEarnings(int Raise, int Price, string Name){ //uses upgrades

        if(Count>=Price){
            Count -= Price;
           
            CountText.text = Count.ToString();
            if(Raise>0){
                Earning += Raise;}
            else if (Raise <0){ 
                ClickValue = Raise*-1;}
            
            if(!CheckName(Name)){//adding the upgrades in the list of unlocked function
            ButtonInUse.Add(Name);}

            if(ButtonInUse.Count == 12){ //temporary => modify when upgrade system finish
                GameObject.Find("AllUpgrades").GetComponent<Achievements_Marvel>().FireAnim();
            }

            return true;

        }
        return false;
    }

    public bool UnlockTech(int Price, string Name){ 

        if((Count>=Price) && !CheckName(Name)){
            if((Name =="Terraforming Device") || (Name == "Research Lab") || (CheckName("Research Lab"))){
                Count -= Price;
           
                CountText.text = Count.ToString();
                
                ButtonInUse.Add(Name);

                return true;
            }
            else{
                StopAllCoroutines();
                StartCoroutine(DisplayInfo("You need the Research Lab to unlock this technology!", new Vector3(-102f,130,InfoPos.z)));
                return false;
            }}
        return false;
        
    }

    private bool CheckName(string Name){
        return ButtonInUse.Contains(Name);
    }

    private void VisualGain(int Value){ //text pop up
        GameObject VisualGain = Instantiate(VisualGainTextPrefab,GameObject.Find("Canvas").transform);
        TMP_Text VisualGainText = VisualGain.GetComponent<TMP_Text>();
        if(Value<0){
            VisualGainText.text = Value.ToString();
            VisualGainText.color = Color.red;
        }
        else{
            VisualGainText.text = "+ " + Value.ToString();
            VisualGainText.color = Color.white;}
        
        
    }

    public void ChangePlanet(int PlanetNb){
        if((PlanetNb < PlanetScript.ArrayPos)&&(PlanetNb>=0)){ //want to go to an old planet
            ButtonInUse = new List<string> {};
            Earning = 0;
            ClickValue = 1;
            ArrayPos = PlanetNb;
            //OldPlanet(PlanetNb)?.Invoke();
            //OldPlanet(PlanetNb);
            int PreviousValue = statManager.GetValue(PlanetNb);
            Count = PreviousValue;
            CountText.text = Count.ToString();

            PlanetMovement.SetTrigger("Leave");
            if(CristalArray[PlanetNb] != CristalInUse){
                CristalInUse = CristalArray[PlanetNb];
                CristalImage.sprite = CristalInUse;
            }
            CurrentType = (Crystals)PlanetNb;
        }
        else if (PlanetNb < 0){// want to go to a new planet
            if((Count >= PlanetScript.TravelCost)&& CheckName("Space Station")){
                Count -= PlanetScript.TravelCost;
                CountText.text = Count.ToString();
                NewPlanetButton.SetActive(false);
                ArrayPos ++;

                PlanetMovement.SetTrigger("Leave");
                if(CristalInUse != CristalArray[ArrayPos])
                    {CristalInUse = CristalArray[ArrayPos];
                    CristalImage.sprite = CristalInUse;
                    Count = 0;}

                TypeInUse = CrystalTypes.Dequeue();
                CurrentType = TypeInUse;
                NewPlanet?.Invoke(); //triger the reset of upgrade and tech buttons
                ButtonInUse = new List<string> {}; // reseting the list
                Earning = 0;
                ClickValue = 1;
            }
            else if((Count >= PlanetScript.TravelCost)&& !CheckName("Space Station")){ // not enough monney to travel
                StopAllCoroutines();
                StartCoroutine(DisplayInfo("You need the Space Station to travel!", new Vector3(312f,73f,InfoPos.z)));
            }}
    }

    IEnumerator DisplayInfo(string Sentence, Vector3 Position){ //Display error message
        InfoText.text = Sentence;
        Info.transform.localPosition = Position;
        InfoText.enabled =true;
        yield return new WaitForSeconds(2f);
        InfoText.enabled =false;
    }

    public void AlienAttack(){
        int Loss = (int)Mathf.Round(Count - Earning/3); //alien take 1/3 of the earnings
        if(Loss >=0){ // can't have negative Count
            Count -= (int)Mathf.Round(Earning/3);
            VisualGain((int)Mathf.Round(-Earning/3));
            CountText.text = Count.ToString();}
    }

}
