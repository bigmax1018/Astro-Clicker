using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Marvel : MonoBehaviour
{
    [TextArea]
    [SerializeField] private string Detail;
    private GameObject PlanetButton;
    private Image Icon;
    public Color LockColor;
    Planet planet;
    // Start is called before the first frame update
    void Start()
    {
        PlanetButton = GameObject.Find("Planet");
        planet = PlanetButton.GetComponent<Planet>();

        Icon = GetComponent<Image>();
        Icon.color = LockColor;
    }


    public void ShowDetails(){
       planet.NovaDisplayDetail(Detail);
    }
}
