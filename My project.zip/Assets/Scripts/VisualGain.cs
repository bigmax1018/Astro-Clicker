using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VisualGain : MonoBehaviour
{
    private Vector3 Pos, Target;
    public float Speed;
    private float t=0;
    // Start is called before the first frame update
    void Start()
    {
        transform.localPosition = new Vector3(104f,69f,0f);
        Pos = transform.localPosition;
        Target = new Vector3(224f,158,0f);
    }

    // Update is called once per frame
    void Update()
    {
        if((Vector3.Distance(transform.localPosition,Target)<0.00001f) || (t>=2f)){
            Destroy(gameObject);
        }
        else{
            transform.localPosition = Vector3.MoveTowards(transform.localPosition, Target, Time.deltaTime * Speed);
            t+=Time.deltaTime;
        }
    }
}
