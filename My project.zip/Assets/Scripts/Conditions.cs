using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class Conditions : MonoBehaviour
{
    //public Crystals AchievementType;
    [TextArea]
    [SerializeField] private string Detail;
    [SerializeField] private string Price;
    [SerializeField] private TMP_Text PriceText;
    private GameObject PlanetButton;
    /*private GameObject CristalCount;
    private GameObject PopUpObject;*/
    private Image Icon;
    public Color LockColor;

    Planet planet;
    AddCristal CristalManager;
    PopUpManager popUpManager;

    // Start is called before the first frame update
    void Start()
    {
        /*CristalCount = GameObject.Find("CrystalManager");
        CristalManager = CristalCount.GetComponent<AddCristal>();*/

        PlanetButton = GameObject.Find("Planet");
        planet = PlanetButton.GetComponent<Planet>();

        /*PopUpObject = GameObject.Find("PopUpAnimManager");
        popUpManager = PopUpObject.GetComponent<PopUpManager>();*/

        Icon = GetComponent<Image>();
        Icon.color = LockColor;
        if(Price.Length <= 7){
            PriceText.text = Price;
        }
        else{
            PriceText.text = ">999,999";
        }
        

        //TypeCheck();

        //CristalManager.NewPlanet += TypeCheck;

    }

    /*private void TypeCheck(){
        if(CristalManager.TypeInUse == AchievementType){
            FireAnim();
        }
    }
    public void FireAnim(){
        Icon.color = Color.white;
        popUpManager.AddToPopUpQueue(Icon.sprite);
    }*/

    public void ShowDetails(){
       planet.NovaDisplayDetail(Detail);
    }
}
